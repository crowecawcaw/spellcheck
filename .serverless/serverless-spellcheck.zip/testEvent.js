// Sample event data
module.exports = {
	queryStringParameters: {
      url: "http://ricechialpha.com"
    }
};
