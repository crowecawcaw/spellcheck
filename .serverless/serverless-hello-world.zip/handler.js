const cheerio = require('cheerio')
const fetch = require('node-fetch')

module.exports.helloWorld = (event, context, callback) => {
  fetch(event.queryStringParameters.url)
  .then(res => res.text())
  .then(html => cheerio.load(html))
  .then($ => $('body').text())
  .then(text => {
    const response = {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*', // Required for CORS support to work
      },
      body: JSON.stringify({
        text: text,
        input: event,
      }),
    };

    callback(null, response);
  })
};
